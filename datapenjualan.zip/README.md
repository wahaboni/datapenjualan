# datapenjualan
Data Penjualan - Software POS Multi Store Input Barang dan Penjualan Laptop Komputer

Terdiri dari Menu 
- Input data
-> Penjualan
-> Barang
- Lihat Data
-> Penjualan
-> Barang

- Multi ID beberapa toko dengan masing2 dibuatkan Hak Akses nya.

** Masih dalam tahap Pengembangan & Penyempurnaan **

--- Bantu kami masukan untuk penyempurnaan program --
